package com.example.repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SharedData {
	
	public static final Map<String, Object> MAP = new HashMap<>();
	
	public static final List<Object> LIST = new ArrayList<>();
	

}
