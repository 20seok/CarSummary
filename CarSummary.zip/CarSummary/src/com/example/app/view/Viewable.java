package com.example.app.view;

import javax.swing.JPanel;

public interface Viewable {
	
	JPanel getView();
	
}
